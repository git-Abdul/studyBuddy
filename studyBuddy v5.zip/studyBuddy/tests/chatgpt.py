import openai

# Set your API key
#sk-None-qC4lOHLXUDtOtsxHeMvET3BlbkFJFlCcF8IcF5Ih0eE2j6cN
openai.api_key = 'sk-proj-YibBzvfHgYyAnTjmKy1HT3BlbkFJIq0I7rk6IBSNzCOAlTlX'

# Make a request
response = openai.Completion.create(
    model="gpt-3.5-turbo",
    prompt="Hello",
    max_tokens=100
)

# Print the response
print(response.choices[0].text.strip())